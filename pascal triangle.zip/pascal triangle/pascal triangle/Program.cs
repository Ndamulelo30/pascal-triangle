﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pascal_triangle
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the number of rows for Pascal's triangle:");
            int numRows = Convert.ToInt32(Console.ReadLine());

            PrintPascalTriangle(numRows);
        }

        static void PrintPascalTriangle(int numRows)
        {
            for (int i = 0; i < numRows; i++)
            {
                // Print spaces for formatting
                for (int j = 0; j < numRows - i; j++)
                {
                    Console.Write(" ");
                }

                // Calculate and print values for the current row
                int val = 1;
                for (int j = 0; j <= i; j++)
                {
                    Console.Write($"{val} ");
                    val = val * (i - j) / (j + 1);
                }

                Console.WriteLine();
            }
        }
    }
}